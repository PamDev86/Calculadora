package com.example.calculadora

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var viewView : TextView
    lateinit var oneButton: Button
    lateinit var twoButton: Button
    lateinit var threeButton: Button
    lateinit var fourButton: Button
    lateinit var fiveButton: Button
    lateinit var sixButton: Button
    lateinit var sevenButton: Button
    lateinit var eightButton: Button
    lateinit var nineButton: Button
    lateinit var ceroButton: Button
    lateinit var sumButton: Button
    lateinit var restButton: Button
    lateinit var multButton: Button
    lateinit var divButton: Button
    lateinit var eqButton: Button
    lateinit var clearButton: Button
    lateinit var pointButton: Button

    var tot: Double = 0.0
    var num: Double = 0.0
    var txt: String = ""
    var oper : String = "null"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewView = findViewById(R.id.viewView)

        clearButton = findViewById(R.id.clearButton)
        clearButton.setOnClickListener {
            doClear()
            viewView.text = "CLEAR"
        }

        oneButton = findViewById(R.id.oneButton)
        oneButton.setOnClickListener {
            txt += "1"
            viewView.text = txt
        }

        twoButton = findViewById(R.id.twoButton)
        twoButton.setOnClickListener {
            txt += "2"
            viewView.text = txt
        }

        threeButton = findViewById(R.id.threeButton)
        threeButton.setOnClickListener {
            txt += "3"
            viewView.text = txt
        }

        fourButton = findViewById(R.id.fourButton)
        fourButton.setOnClickListener {
            txt += "4"
            viewView.text = txt
        }

        fiveButton = findViewById(R.id.fiveButton)
        fiveButton.setOnClickListener {
            txt += "5"
            viewView.text = txt
        }

        sixButton = findViewById(R.id.sixButton)
        sixButton.setOnClickListener {
            txt += "6"
            viewView.text = txt
        }

        sevenButton = findViewById(R.id.sevenButton)
        sevenButton.setOnClickListener {
            txt += "7"
            viewView.text = txt
        }

        eightButton = findViewById(R.id.eightButton)
        eightButton.setOnClickListener {
            txt += "8"
            viewView.text = txt
        }

        nineButton = findViewById(R.id.nineButton)
        nineButton.setOnClickListener {
            txt += "9"
            viewView.text = txt
        }

        ceroButton = findViewById(R.id.ceroButton)
        ceroButton.setOnClickListener {
            txt += "0"
            viewView.text = txt
        }

        pointButton = findViewById(R.id.pointButton)
        pointButton.setOnClickListener {
            txt += "."
            viewView.text = txt
        }

        sumButton = findViewById(R.id.sumButton)
        sumButton.setOnClickListener {
            doSum()
            oper = "+"
            viewView.text = "$oper"
        }

        restButton = findViewById(R.id.restButton)
        restButton.setOnClickListener {
            doRes()
            oper = "-"
            viewView.text = "$oper"
        }

        multButton = findViewById(R.id.multButton)
        multButton.setOnClickListener {
            doMult()
            oper = "*"
            viewView.text = "$oper"
        }

        divButton = findViewById(R.id.divButton)
        divButton.setOnClickListener {
            num = txt.toDouble()
            doDiv()
            oper = "/"
            viewView.text = "$oper"
        }

        eqButton = findViewById(R.id.eqButton)
        eqButton.setOnClickListener {
            if (oper == "+"){
                doSum()
                viewView.text = "$tot"
            }
            if (oper == "-"){
                doRes()
                viewView.text = "$tot"
            }
            if (oper == "*"){
                doMult()
                viewView.text = "$tot"
            }
            if (oper == "/"){
                num = txt.toDouble()
                //Divide 0/0
                if (num == tot && num == 0.0){viewView.text = "Error"}
                //Divide 1/0
                if (num == 0.0 && tot > 0.0){viewView.text = "Cannot divide by zero"}
                if (num > 0.0 && tot > 0.0){
                    doDiv()
                    viewView.text = "$tot"
                }
            }
        }
    }

    fun doSum(){
        num = txt.toDouble()
        tot = tot + num
        txt = ""
    }

    fun doRes(){
        num = txt.toDouble()
        if (tot == 0.0){
            tot = num
        } else {
            tot = tot - num
        }
        txt = ""
    }

    fun doMult(){
        num = txt.toDouble()
        //No permite que el primer numero se multiplique con el 0 cuando es el primero
        if (tot == 0.0){
            tot = num
        } else {
            tot = tot * num
        }
        txt = ""
    }

    fun doDiv(){
        if (tot == 0.0){
            tot = num
        } else {
            tot = tot / num
        }
        txt = ""
    }

    fun doClear(){
        tot = 0.0
        num = 0.0
        txt = ""
        oper = ""
    }
}